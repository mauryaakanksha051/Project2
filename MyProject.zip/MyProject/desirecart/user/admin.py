from django.contrib import admin

# Register your models here.
from.models import *

class productAdmin(admin.ModelAdmin):
    list_display = ('id','category','subcategory','name','price','disprice','size','description','date','color','ppic')
admin.site.register(product,productAdmin)

class subcategoryAdmin(admin.ModelAdmin):
    list_display = ('id','name','date')
admin.site.register(subcategory,subcategoryAdmin)

class orderAdmin(admin.ModelAdmin):
    list_display=('pid','userid','remark','status')
admin.site.register(order,orderAdmin)

class signupAdmin(admin.ModelAdmin):
    list_display=('name','mob','email','passwd','userpic','address')
admin.site.register(signup,signupAdmin)

class addtocartAdmin(admin.ModelAdmin):
    list_display=('cid','pid','userid','odate','status')
admin.site.register(addtocart,addtocartAdmin)

class contactinfoAdmin(admin.ModelAdmin):
    list_display = ('id','name','email','mobno','msg')
admin.site.register(contactinfo,contactinfoAdmin)

class feedbackinfoAdmin(admin.ModelAdmin):
    list_display = ('id','name','img','state','msg')
admin.site.register(feedbackinfo,feedbackinfoAdmin)