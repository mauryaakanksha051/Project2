from django.urls import path
from .import views
urlpatterns = [
    path('',views.index),
    path('index/',views.index),
    path('mensproduct/',views.mensproduct),
    path('contact/',views.contactus),
    path('womensproduct/',views.womensproduct),
    path('kidsproduct/',views.kidsproduct),
    path('myorder/',views.myorder),
    path('myprofile/',views.myprofile),
    path('viewproduct/',views.viewproduct),
    path('register/',views.signup1),
    path('signin/',views.signin),
    path('signin1/',views.signin1),
    path('logout/',views.logout1),
    path('cart/',views.cartItem),
    path('feedback/',views.feedback),

]