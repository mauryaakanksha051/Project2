import datetime
from django.http import HttpResponse
from django.shortcuts import render
from.models import *
from django.db import connection
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate,login,logout

# Create your views here.
def index(request):
    mproduct=product.objects.all().order_by('-id')[:8]
    noofitemsincart=""
    if request.user.is_authenticated:
        uname=request.user
        noofitemsincart=addtocart.objects.filter(userid=uname,status=True).count()
    return render(request,'user/index.html',{"mixproduct":mproduct,"cart":noofitemsincart})

def mensproduct(request):
    noofitemsincart = ""
    a=request.GET.get('msg')
    if a==None:
        pdata=product.objects.filter(category='Mens')
    else:
        pdata=product.objects.filter(category='Mens',subcategory=a)
    scat=subcategory.objects.all().order_by('-id')
    if request.user.is_authenticated:
        uname = request.user
        noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
    mydict={"data":pdata,"subcat":scat,"cart":noofitemsincart}
    return render(request,'user/mensproduct.html',mydict)

def contactus(request):
    noofitemsincart=""
    status=False
    if request.method=='POST':
        Name=request.POST.get("name","")
        Mobile=request.POST.get("mobno","")
        Message= request.POST.get("msg","")
        Email = request.POST.get("email","")
        res=contactinfo(name=Name,email=Email,msg=Message,mobno=Mobile)
        res.save()
        status=True
        if request.user.is_authenticated:
            uname = request.user
            noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
    return render(request,'user/contact.html',context={"S":status,"cart":noofitemsincart})

def womensproduct(request):
    noofitemsincart = ""
    a=request.GET.get('msg')
    if a == None:
        pdata=product.objects.filter(category='Womens')
    else:
        pdata=product.objects.filter(category='Womens', subcategory=a)
    scat=subcategory.objects.all().order_by('-id')
    if request.user.is_authenticated:
        uname = request.user
        noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
    myDict={"data":pdata, "subcat":scat,"cart":noofitemsincart}
    return render(request,'user/womensproduct.html',myDict)


def kidsproduct(request):
    noofitemsincart = ""
    a = request.GET.get('msg')
    if a == None:
        pdata = product.objects.filter(category='Kids')
    else:
        pdata = product.objects.filter(category='Kids', subcategory=a)
    scat = subcategory.objects.all().order_by('-id')
    if request.user.is_authenticated:
        uname = request.user
        noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
    myDict = {"data": pdata, "subcat": scat,"cart":noofitemsincart}
    return render(request, 'user/kidsproduct.html', myDict)

def myorder(request):
    deliveredProduct=""
    uname=request.user
    orderdetails=""
    noofitemsincart = ""
    if request.user.is_authenticated:
        cursor = connection.cursor()
        cursor.execute("select o.pid,o.userid,o.remark,o.status,o.odate,p.name,p.disprice,p.size,p.color,p.description,p.ppic,p.id from user_order o, user_product p where o.pid=p.id and o.userid='"+str(uname)+"' and o.status=True and o.remark='added by admin' order by o.id desc")
        orderdetails = cursor.fetchall()
        cursor.execute("select o.pid,o.userid,o.remark,o.status,o.odate,p.name,p.disprice,p.size,p.color,p.description,p.ppic from user_order o, user_product p where o.pid=p.id and o.userid='"+str(uname)+"' and o.status=True and o.remark='delivered' order by o.id desc")
        deliveredProduct=cursor.fetchall()
        uname = request.user
        noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
        cid = request.GET.get('del')
        if request.GET.get('del'):
            a = order.objects.filter(pid=cid)
            a.delete()
            return HttpResponse("<script>alert('Order cancel successfully...');window.location.href='/user/myorder/';</script>")
    return  render(request,'user/myorder.html',{"order":orderdetails,"dorder":deliveredProduct,"cart":noofitemsincart})

def myprofile(request):
    userdetails=""
    noofitemsincart=""
    if request.user.is_authenticated:
        uname=request.user
        data = signup.objects.filter(email=uname)
    if request.user.is_authenticated:
        uname=request.user
        noofitemsincart=addtocart.objects.filter(userid=uname,status=True).count()
        userdetails=signup.objects.filter(email=uname)
        if request.method=="POST":
            name=request.POST['name']
            mobile=request.POST['mobile']
            upic=request.FILES['fu']
            address=request.POST['address']
            res=signup(email=uname,name=name,mob=mobile,address=address,userpic=upic)
            res.save()
        return render(request,'user/myprofile.html',{"mdata":data,"cart":noofitemsincart,"udetails":userdetails})
    return HttpResponse("<script>alert('Please login first');window.location.href='/user/signin/';</script>")


def viewproduct(request):
    noofitemsincart = ""
    pid=request.GET.get('pid')
    data=product.objects.filter(id=pid)
    if request.user.is_authenticated:
        uname = request.user
        noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
    return render(request,'user/viewproduct.html',context={"pdata":data,"cart":noofitemsincart})

def signup1(request):
    noofitemsincart = ""
    status=False
    if request.method=='POST':
        if request.POST.get('passwd')==request.POST.get('cpasswd'):
             Name=request.POST.get('name',"")
             Email=request.POST.get('email',"")
             Mobile=request.POST.get('mob',"")
             Profile=request.FILES.get('userpic',"")
             Password=request.POST.get('passwd',"")
             Cpassword=request.POST.get('cpasswd',"")
             Address = request.POST.get('address',"")
             res=signup(name=Name,email=Email,mob=Mobile,userpic=Profile,passwd=Password,address=Address)
             res.save()
             myuser=User.objects.create_user(Email,Email,Password)
             myuser.first_name=Name
             myuser.last_name=Name
             status = True
        if request.user.is_authenticated:
            uname = request.user
            noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()
    return render(request,'user/signup.html',context={"msg":status,"cart":noofitemsincart})

def signin(request):
    if request.user.is_authenticated:
        page=request.GET.get('page')
        pid=request.GET.get('pid')
        username=request.user
        if page == 'cart':
            checkItem=addtocart.objects.filter(pid=pid,userid=username,status=True)
            if checkItem:
                return render(request,'user/signin.html',context={"alreadyadded":True})
            savetocart=addtocart(pid=pid,userid=username,status=True,odate=datetime.datetime.now())
            savetocart.save()
        elif page=='order':
            savetoorder=order(pid=pid,userid=username,remark="added by admin",status=True,odate=datetime.datetime.now())
            savetoorder.save()
            return HttpResponse("<script>alert('Your order is confirmed..');window.location.href='/user/myorder/';</script>")
        elif page=='orderfromcart':
            cartrecord=addtocart.objects.filter(pid=pid,userid=username,status=True)
            cartrecord.delete()
            savetocart = addtocart(pid=pid, userid=username, status=True, odate=datetime.datetime.now())
            savetocart.save()
            return HttpResponse("<script>alert('your order is confirmed');window.location.href='/user/myorder/';</script>")

        return render(request, 'user/signin.html',context={"alreadylogin": True})
    else:
        print('not ok')
    return render(request,'user/signin.html')

def signin1(request):
    if request.method =='POST':
        username=request.POST.get('uname', "")
        password=request.POST.get('password', "")
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return render(request, 'user/signin.html',context={"User": True})
        else:
            return render(request, 'user/signin.html',context={"Nouser": True})

    return render(request, 'user/signin.html')

def logout1(request):
    logout(request)
    return render(request,'user/index.html')

def cartItem(request):
    noofitemsincart = ""
    cartvalue=""
    uname=request.user
    if request.user.is_authenticated:
        cursor=connection.cursor()
        cursor.execute("select p.id,p.name,p.price,p.disprice,p.size,p.color,p.ppic,c.userid,c.odate,c.id,c.status from user_product p,user_addtocart c where p.id=c.pid and c.userid='"+str(uname)+"' and c.status=True")
        cartvalue=cursor.fetchall()
        cid = request.GET.get('del')
        if request.GET.get('del'):
            a=addtocart.objects.filter(id=cid)
            a.delete()
            return HttpResponse("<script>alert('your item is removed');window.location.href='/user/cart/';</script>")
        if request.user.is_authenticated:
            uname = request.user
            noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()

    return render(request,'user/cart.html',{"cartItem":cartvalue,"cart":noofitemsincart})

def feedback(request):
    pdata = feedbackinfo.objects.all()
    noofitemsincart=""
    if request.method == 'POST':
        Name = request.POST.get("name", "")
        Pic = request.FILES.get("img", "")
        State = request.POST.get("state", "")
        Message = request.POST.get("msg", "")
        res = feedbackinfo(name=Name, img=Pic, state=State, msg=Message)
        res.save()
        if request.user.is_authenticated:
            uname = request.user
            noofitemsincart = addtocart.objects.filter(userid=uname, status=True).count()

    return render(request, 'user/feedback.html',{"data1":pdata,"cart":noofitemsincart})
