from django.db import models

class subcategory(models.Model):
    id=models.AutoField
    name=models.CharField(max_length=60)
    date=models.DateField()
    def __str__(self):
        return self.name


class product(models.Model):
    id=models.AutoField
    category=models.CharField(max_length=20)
    subcategory=models.ForeignKey(subcategory,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    price=models.FloatField()
    disprice=models.FloatField()
    size=models.CharField(max_length=10)
    description=models.CharField(max_length=300)
    date=models.DateField()
    color=models.CharField(max_length=35)
    ppic = models.ImageField(upload_to="static/images/", default="");

    def __str__(self):
        return self.name

class contactinfo(models.Model):
    id=models.AutoField
    name=models.CharField(max_length=70)
    email=models.CharField(max_length=100)
    mobno=models.CharField(max_length=20)
    msg=models.CharField(max_length=1000)

    def __str__(self):
        return self.name

class order(models.Model):
    order=id=models.AutoField
    pid=models.IntegerField()
    userid=models.CharField(max_length=50)
    remark=models.TextField(max_length=1000)
    status=models.BooleanField()
    odate=models.DateField()

    def __str__(self):
        return self.userid

class addtocart(models.Model):
    cid=models.AutoField
    pid=models.IntegerField()
    userid=models.CharField(max_length=50)
    status=models.BooleanField()
    odate=models.DateField()

    def __str__(self):
        return self.userid

class signup(models.Model):
    id=models.AutoField
    name=models.CharField(max_length=50)
    mob=models.CharField(max_length=25)
    email=models.CharField(max_length=50,primary_key=True)
    userpic=models.ImageField(upload_to='static/profile/',null=True)
    passwd=models.CharField(max_length=30)
    cpasswd=models.CharField(max_length=30)
    address=models.TextField(max_length=500)

    def __str__(self):
        return self.name

class feedbackinfo(models.Model):
    id=models.AutoField
    name=models.CharField(max_length=70)
    img=models.ImageField(upload_to="static/upload/testimonial/",default="");
    state=models.CharField(max_length=100)
    msg=models.CharField(max_length=2000)
    def __str__(self):
        return self.name